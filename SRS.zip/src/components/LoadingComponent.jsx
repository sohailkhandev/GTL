// loading component shows when app context loading is true
import React from "react";

const LoadingComponent = () => {
  return <div>Loading...</div>;
};

export default LoadingComponent;
